# -*- coding: utf-8 -*-
"""
Chaining Multiple Stainers on DirtyDF
=====================================

This page shows some typical use-cases of 'chainstaining' multiple stainers together to produce several distinct transformed
DirtyDFs, based on an original DirtyDF. We expect this to be the most common use-case of this library.
"""