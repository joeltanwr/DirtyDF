# -*- coding: utf-8 -*-
"""
User-defined Custom Stainers
============================

This page shows an example of how to create your own user-defined custom stainers, which subclasses from the Stainer class.
"""