# -*- coding: utf-8 -*-
"""
Retail Dataset Example
======================

This page shows some typical use-cases of 'chainstaining' multiple stainers together to produce several distinct transformed
DirtyDFs, based on a retail dataset. We expect these types of procedures to be the most common use-case of this library.
"""