# -*- coding: utf-8 -*-
"""
Basic Usage of DirtyDF with Stainers
====================================

This page shows some basic examples of using DirtyDF, and applying stainers to transform them.
"""